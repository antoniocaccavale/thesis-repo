/* ==================================== Motion Planning Dual Arms ================================
************************************** ICAROS ******************************
                            All Rights are reserved By
                         University of Naples Federico II

Author: Mohammad Hossein Hamedani
Emai:
Date:
Compiler:gnu++/catkin build

Revision History
-----------------------------------
V01: 2022/02/04  Initial Version

=============================================================================*/
/* Including General C++ Header(s) */
#include <exception>
#include <string>
#include <boost/shared_ptr.hpp>
#include <vector>
#include <map>

/* Including ROS Header(s) */
#include <ros/ros.h>
#include <geometry_msgs/PointStamped.h>
#include <control_msgs/PointHeadAction.h>
#include <control_msgs/FollowJointTrajectoryAction.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>


/* include Moveit Headers(s) */
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <geometric_shapes/shape_operations.h>


/* include Icarso Header */
#include <icaros_object_rcg/icr_msg_box.h>
#include <icaros_tiago_navigation/IcarosNavigationAction.h>

// Our Action interface type for moving TIAGo++'s head, provided as a typedef for convenience
typedef actionlib::SimpleActionClient<control_msgs::PointHeadAction> PointHeadClient;
typedef boost::shared_ptr<PointHeadClient> PointHeadClientPtr;


// Our Action interface type for moving TIAGo++'s Gripper, provided as a typedef for convenience
typedef actionlib::SimpleActionClient<control_msgs::FollowJointTrajectoryAction> PointGripperClient;
typedef boost::shared_ptr<PointGripperClient> PointGripperClientPtr;

// Our Action interface type for moving TIAGo++'s Gripper, provided as a typedef for convenience
typedef actionlib::SimpleActionClient<control_msgs::FollowJointTrajectoryAction> gripper_control_client;
typedef boost::shared_ptr<gripper_control_client> gripper_control_client_ptr;

// Our Action interface type for moving TIAGo++'s Base, provided as a typedef for convenience
typedef actionlib::SimpleActionClient<icaros_tiago_navigation::IcarosNavigationAction> base_control_client;
typedef boost::shared_ptr<base_control_client> base_control_client_ptr;

// Our Action interface type for moving TIAGo++'s Gripper, provided as a typedef for convenience
typedef actionlib::SimpleActionClient<control_msgs::FollowJointTrajectoryAction> torso_control_client;
typedef boost::shared_ptr<torso_control_client> torso_control_client_ptr;


class icr_Motionplanning_arms
{
private:
  /* data */
public:
  icr_Motionplanning_arms(/* args */);
  ~icr_Motionplanning_arms();

  /* ----------- Gripper Position Control ---------- */
  void GripperControl(int motion_type);
  void createGripperClient(gripper_control_client_ptr&  , const std::string );
  void Left_Gripper_SendAction(gripper_control_client_ptr, int);
  void Right_Gripper_SendAction(gripper_control_client_ptr, int);

  /* ----------- Torso Control ---------- */
  void TorsoMotionPlanning(void);
  void TorsoControl(double lift_value);
  void TorsoSendAction(torso_control_client_ptr torso_client, double lift_value);

  /* ----------- ARM Position Control ---------- */
  void  ARM_Homeposition(void);
  int   ArmMotionPlanning(geometry_msgs::PoseStamped, geometry_msgs::PoseStamped, int motion_type);
  int   Box_Pose_Verify(void);
  void  Pose_X_Arm (int motion_type);
  void  Pose_Y_Arm (int motion_type);
  void  Pose_Z_Arm (int motion_type); 

   
  void motion_planning_contorl (int motion_arms);  
  void Set_initial_motion(int motion_type);
  void Approaching_to_initial_pose(int motion_type);



};


