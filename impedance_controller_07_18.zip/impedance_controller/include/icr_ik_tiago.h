/* ==================================== main ================================
************************************** ICAROS ******************************
                            All Rights are reserved By
                         University of Naples Federico II

Author: Mohammad Hossein Hamedani
Emai:
Date:
Compiler:gnu++/catkin build

Revision History
-----------------------------------
V01: 2022/02/04  Initial Version

=============================================================================*/
/* Including General C++ Header(s) */
#include <exception>
#include <string>
#include <boost/shared_ptr.hpp>
#include <vector>
#include <map>

/* Including ROS Header(s) */
#include <ros/ros.h>
#include <geometry_msgs/PointStamped.h>
#include <control_msgs/PointHeadAction.h>
#include <control_msgs/FollowJointTrajectoryAction.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>


/* include Moveit Headers(s) */
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <geometric_shapes/shape_operations.h>


/* include Icarso Header */
#include <icaros_object_rcg/icr_msg_box.h>
#include <icaros_tiago_navigation/IcarosNavigationAction.h>

/* PAL Header */
#include "pal_common_msgs/DisableAction.h"

// Our Action interface type for moving TIAGo++'s head, provided as a typedef for convenience
typedef actionlib::SimpleActionClient<control_msgs::PointHeadAction> PointHeadClient;
typedef boost::shared_ptr<PointHeadClient> PointHeadClientPtr;


// Our Action interface type for moving TIAGo++'s Heade Manager Disable, provided as a typedef for convenience
typedef actionlib::SimpleActionClient<pal_common_msgs::DisableAction> HeadManagerClient;
typedef boost::shared_ptr<HeadManagerClient> HeadManagerClientPtr;

// Our Action interface type for moving TIAGo++'s Gripper, provided as a typedef for convenience
typedef actionlib::SimpleActionClient<control_msgs::FollowJointTrajectoryAction> PointGripperClient;
typedef boost::shared_ptr<PointGripperClient> PointGripperClientPtr;

// Our Action interface type for moving TIAGo++'s Gripper, provided as a typedef for convenience
typedef actionlib::SimpleActionClient<control_msgs::FollowJointTrajectoryAction> gripper_control_client;
typedef boost::shared_ptr<gripper_control_client> gripper_control_client_ptr;

// Our Action interface type for moving TIAGo++'s Base, provided as a typedef for convenience
typedef actionlib::SimpleActionClient<icaros_tiago_navigation::IcarosNavigationAction> base_control_client;
typedef boost::shared_ptr<base_control_client> base_control_client_ptr;


class icr_ik_tiago
{
private:
    /* data */
public:

    icr_ik_tiago(ros::NodeHandle& nh, ros::NodeHandle& pnh, ros::NodeHandle& nh_1);
    virtual ~icr_ik_tiago();
   
 #if 0  
   icr_ik_tiago(/* args */)
    {

    }

    ~icr_ik_tiago()
    {

    }
  #endif

    void object_pose(const icaros_object_rcg::icr_msg_box::Ptr& box_pose);

    void obstacle_pose(const geometry_msgs::PoseStamped::Ptr& table_pose);

    void obstacle_dimension(const geometry_msgs::PoseStamped::Ptr& table_dimension); 

#if 0
    /* ----------- ARM Position Control---------- */
    void ARM_Homeposition(void);
    void ARM_SideBoxApproaching(void);


    


    /* ----------- Gripper Position Control ---------- */
    void createGripperClient(gripper_control_client_ptr&  , const std::string );
    void Left_Gripper_SendAction(gripper_control_client_ptr);
    void Right_Gripper_SendAction(gripper_control_client_ptr);

   
    

#endif

    /* ----------- Head Position Control ---------- */
    void createHeadClient(PointHeadClientPtr& actionClient);
    void Head_SendAction(PointHeadClientPtr);

    /* ----------- Head Manager Disable Control ---------- */
    void createHeadManagerClient(HeadManagerClientPtr& );
    void HeadManagerDsiable_SendAction(HeadManagerClientPtr, int);

    /* ----------- Base Position Control ---------- */
    void createBaseClient(base_control_client_ptr&);
    void Base_SendAction(std::string str);
    void Mobile_Base_Pose(const geometry_msgs::PoseWithCovarianceStamped::Ptr&);

    /* ----------- General Function ---------- */
    int Approaching(int motion_type);
    void start();
    void stop();
    void run();


    ros::NodeHandle& _nh, _pnh,_nh_1;
    ros::CallbackQueue _cbQueue;
    ros::CallbackQueue _cbtableQueue;
    bool    _enabled;
    double  _rate;

    /* Ros Interafce */
    ros::Subscriber _SubBoxPosition;
    ros::Subscriber _SubTablePosition;
    ros::Subscriber _SubTableDimension;
    ros::Subscriber _SubCurRobotPos;
    ros::Publisher  _icarosBaseControlPub;

    ros::Publisher  _pubGripperPose;
    ros::Publisher  _pubTorsoPose;

};

