/* ==================================== main ================================
************************************** ICAROS ******************************
                            All Rights are reserved By
                         University of Naples Federico II

Author: Mohammad Hossein Hamedani
Email:
Date:
Compiler:gnu++/catkin build

Revision History
-----------------------------------
V01: 2022/02/04  Initial Version

=============================================================================*/

#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include "std_msgs/String.h"

/* ----- Icaros Headers ----- */
#include "icr_ik_tiago.h"
#include "icr_Motionplanning_arms.h"
#include <icaros_object_rcg/icr_msg_box.h>
#include "impedance_controller.h"

//ROS headers
#include <actionlib/client/simple_action_client.h>
#include <play_motion_msgs/PlayMotionAction.h>
#include <ros/package.h>
#include <actionlib/client/simple_action_client.h>
#include <geometry_msgs/PointStamped.h>
#include <control_msgs/PointHeadAction.h>
#include <control_msgs/FollowJointTrajectoryAction.h>

// C++ standard headers
#include <cstdlib>
#include <yaml-cpp/yaml.h>
#include <signal.h>


/* ---- PAL Headers ----- */



/* ------- Definitions -------- */
#define TEST_RUN 0

#define HOME_POS  0x01
#define TABLE_POS 0x02
#define STOP_NAV  0x03

#define DISABLE   0x00
#define ENABLE    0x01
#define VALID     0x02
#define NOT_VALID 0x03




/* ----- GLOBAL VARIABLES ------ */
geometry_msgs::PoseStamped Obstacle_msg_pose;
geometry_msgs::PoseStamped Obstacle_msg_dim;
geometry_msgs::PoseStamped Box_pose;
geometry_msgs::PoseStamped Box_pose_left;
geometry_msgs::PoseStamped Box_pose_right;
int   Box_Pose_update     = DISABLE;
bool  Table_Pose_update   = false;
bool  Dim_Pose_update     = false;
int   Try_Cnt_Approach    = 0;
static volatile sig_atomic_t running_proccess = 1;
HeadManagerClientPtr HeadManager;

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
icr_ik_tiago::icr_ik_tiago(ros::NodeHandle& nh, ros::NodeHandle& pnh, ros::NodeHandle& nh_1):
_nh(nh),
_pnh(pnh),
_nh_1(nh),
_enabled(false),
_rate(100.0)
{
   _nh.setCallbackQueue(&_cbQueue);
   _nh_1.setCallbackQueue(&_cbtableQueue);
   pnh.param<double>("rate", _rate, _rate);

}

icr_ik_tiago::~icr_ik_tiago()
{

}

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_ik_tiago::start()
{
  _SubBoxPosition    = _nh.subscribe("/icaros_object_recognition/box_pose_points", 1, &icr_ik_tiago::object_pose, this);
  _SubTablePosition  = _nh_1.subscribe("/icaros_object_recognition/table_pose", 1, &icr_ik_tiago::obstacle_pose, this);
  _SubTableDimension = _nh.subscribe("/icaros_object_recognition/table_dimension", 1, &icr_ik_tiago::obstacle_dimension, this);
  _SubCurRobotPos    = _nh.subscribe("/robot_pose", 1, &icr_ik_tiago::Mobile_Base_Pose, this);
  _icarosBaseControlPub  = _pnh.advertise<std_msgs::String>("icaros_base_control", 1);
  _enabled = true;
}


/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_ik_tiago::stop()
{
  _SubBoxPosition.shutdown();
  _SubTablePosition.shutdown();
  _SubTableDimension.shutdown();
  _SubCurRobotPos.shutdown();
  _icarosBaseControlPub.shutdown();

  _enabled = false;
}

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void  icr_ik_tiago::createHeadManagerClient(HeadManagerClientPtr& actionClient)
{
  
  ROS_INFO("Creating action client to Head Manager controller ...");

  actionClient.reset( new HeadManagerClient("/pal_head_manager/disable") );

  int iterations = 0, max_iterations = 3;
  // Wait for head controller action server to come up
  while( !actionClient->waitForServer(ros::Duration(2.0)) && ros::ok() && iterations < max_iterations )
  {
    ROS_DEBUG("Waiting for the head manager server to come up");
    ++iterations;
  }

  if ( iterations == max_iterations )
    throw std::runtime_error("Error in createHeadManagerClient: head manager action server not available");
   
}

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_ik_tiago::HeadManagerDsiable_SendAction(HeadManagerClientPtr headmanager_client, int head_state)
{
  float time_disable_duration = 50 ;  /* Second */
  //pal_common_msgs::DisableAction disable_action;
  //disable_action.action_goal.goal.duration = time_disable_duration;
  //head_goal.target.header.stamp = ros::Time::now();
  if (head_state == ENABLE)
  {
    pal_common_msgs::DisableGoal disable_action;
    disable_action.duration = time_disable_duration;
    headmanager_client->sendGoal(disable_action);
  }
  else
  {
    headmanager_client->cancelGoal();
    //headmanager_client->cancelGoalsAtAndBeforeTime(ros::Time::now());
    //headmanager_client->cancelAllGoals();
  }
  

}

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void  icr_ik_tiago::createHeadClient(PointHeadClientPtr& actionClient)
{
  ROS_INFO("Creating action client to head controller ...");

  actionClient.reset( new PointHeadClient("/head_controller/point_head_action") );

  int iterations = 0, max_iterations = 3;
  // Wait for head controller action server to come up
  while( !actionClient->waitForServer(ros::Duration(2.0)) && ros::ok() && iterations < max_iterations )
  {
    ROS_DEBUG("Waiting for the point_head_action server to come up");
    ++iterations;
  }

  if ( iterations == max_iterations )
    throw std::runtime_error("Error in createPointHeadClient: head controller action server not available");
}

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_ik_tiago::Head_SendAction(PointHeadClientPtr head_client)
{
  geometry_msgs::PointStamped pointStamped;
  pointStamped.header.frame_id = "/base_link";
  //pointStamped.header.stamp    = latestImageStamp;
  /* Diatnace from (x, y ,z) to head to see 
   In fact x = 1.5 (The robot try to see the poisnt (1.5, 0, 0 ))
   in the cartesian space
  */ 
  pointStamped.point.x = 1.5;   /* --- Using the x,y,z parameter to move head --- */
  pointStamped.point.y = 0;
  pointStamped.point.z = 0;   
  
  control_msgs::PointHeadGoal head_goal; //build the action goal
  //the goal consists in making the Z axis of the cameraFrame to point towards the pointStamped
  head_goal.pointing_frame  = "/head_2_link";
  head_goal.pointing_axis.x = 0.0;
  head_goal.pointing_axis.y = 0.0;
  head_goal.pointing_axis.z = 0.0;
  head_goal.min_duration    = ros::Duration(1.0);
  head_goal.max_velocity    = 0.25;
  head_goal.target.header.frame_id = "/base_link";
  head_goal.target = pointStamped;

  //head_goal.target.header.stamp = ros::Time::now();
  head_client->sendGoal(head_goal);

  ROS_INFO("Waiting for result Head action ...");
  bool actionOk = head_client->waitForResult(ros::Duration(90.0));

  actionlib::SimpleClientGoalState state = head_client->getState();

  if (actionOk )
    ROS_INFO_STREAM("Action Head finished successfully with state: " << state.toString());
  else
    ROS_ERROR_STREAM("Action Head failed with state: " << state.toString());

}

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void  icr_ik_tiago::createBaseClient(base_control_client_ptr& actionClient)
{

  actionlib::SimpleActionClient<icaros_tiago_navigation::IcarosNavigationAction> Base_Action ("/ICAROS_BASE_NAV", true);
  Base_Action.waitForServer();
  ROS_INFO("Base Action Client Connetcted ...");

  /* Send Goal to Action Client */
  icaros_tiago_navigation::IcarosNavigationGoal Action_Goal;
  Action_Goal.Deisred_Position = HOME_POS;
  Base_Action.sendGoal(Action_Goal);

  bool time_out = Base_Action.waitForResult(ros::Duration(30.0));

  if (time_out)
  {
    actionlib::SimpleClientGoalState state = Base_Action.getState();
    ROS_INFO ("Base Action Finished: %s",  state.toString().c_str());

  }
  else
  {
    ROS_INFO (" Action did not finish before the time out ");
  }
  #if 0
  actionClient.reset( new base_control_client_ptr("/BASE_ACTION_SERVER") );
  
  int iterations = 0, max_iterations = 3;
  // Wait for head controller action server to come up
  while( !actionClient->waitForServer(ros::Duration(2.0)) && ros::ok() && iterations < max_iterations )
  {
    ROS_DEBUG("Waiting for the base action server to come up");
    ++iterations;
  }

  if ( iterations == max_iterations )
    throw std::runtime_error("Error in createPointHeadClient: base controller action server not available");
 #endif
}
/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void  icr_ik_tiago::Base_SendAction(std::string str)
{
  actionlib::SimpleActionClient<icaros_tiago_navigation::IcarosNavigationAction> Base_Action ("/ICAROS_BASE_NAV", true);
  Base_Action.waitForServer();
  ROS_INFO("Base Action Client Connetcted ...");

  /* Send Goal to Action Client */
  icaros_tiago_navigation::IcarosNavigationGoal Action_Goal;
  if (str == "HOME_POS")
  {
    Action_Goal.Deisred_Position = HOME_POS;
    ROS_INFO("Send Move Base to Home Position");
  }
  else if (str == "TABLE_POS")
  {
    Action_Goal.Deisred_Position = TABLE_POS;
    ROS_INFO("Send Move base to Table Position");
  }
  else if(str == "STOP_NAV")
  {
    Action_Goal.Deisred_Position = STOP_NAV;
    ROS_INFO("Navigation Stop");
  }
  Base_Action.sendGoal(Action_Goal);

  /* ----- Chenck the Action ------ */
  bool time_out = Base_Action.waitForResult(ros::Duration(30.0));
  if (time_out)
  {
    actionlib::SimpleClientGoalState state = Base_Action.getState();
    ROS_INFO ("Base Action Finished: %s",  state.toString().c_str());

  }
  else
  {
    ROS_INFO (" Action did not finish before the time out ");
  }
}

geometry_msgs::PoseWithCovarianceStamped::Ptr MobileBasePose(new geometry_msgs::PoseWithCovarianceStamped);
/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_ik_tiago::Mobile_Base_Pose(const geometry_msgs::PoseWithCovarianceStamped::Ptr& robot_current_pose)
{
  MobileBasePose = robot_current_pose;
  //if (Read_Pose_first_flag == 0)
  //{
  //  Goal_RobotPose.Home_PosX = MobileBasePose->pose.pose.position.x;
  // Goal_RobotPose.Home_PosX = MobileBasePose->pose.pose.position.y;
  // Read_Pose_first_flag = 1;
  //}
}


#define GO_TO_DESK        0x00
#define HEAD_POSE         0x01
#define GRIPPER_POSE      0x02
#define ARM_POSE          0x03
#define APPROACHING_DONE  0x04
#define HOME_ARM_POSE     0x05
/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
int icr_ik_tiago::Approaching(int motion_type)
{

  static int first_approaching_exe = ENABLE;
/* Test  */
//static int Home_task_state = ARM_POSE;
//Box_Pose_update = VALID;
/* Real  */
static int Home_task_state = HOME_ARM_POSE;

icr_Motionplanning_arms obj_armsmotion;
int approaching_result = EXIT_SUCCESS;



//Home_task_state = ARM_POSE;
#if 0
  /* ------ Go to Home: Base Control ------ */
  //createBaseClient(pointBaseClient);
  Base_SendAction("HOME_POS");
#endif

/* ======== Go to Desk: Base Control ======== */
if (Home_task_state == GO_TO_DESK)
{
  //if (MobileBasePose->pose.pose.position.x == 0 && MobileBasePose->pose.pose.position.y == 0)
  {
    ROS_INFO("Go to Table Position");
    Base_SendAction("TABLE_POS");
  }
  Home_task_state = HOME_ARM_POSE;
}

/* ======== Home Pose Arms ======== */
else if (Home_task_state == HOME_ARM_POSE)
{
  
  /* ---- Disable Head Manager ---- */
  //createHeadManagerClient(HeadManager);
  //HeadManagerDsiable_SendAction(HeadManager, ENABLE);

  /* ----- Arm Home Position ------ */
  obj_armsmotion.ARM_Homeposition();
  //return EXIT_SUCCESS;
  Home_task_state = HEAD_POSE;
}

/* ============ Head Control =========== */
else if (Home_task_state == HEAD_POSE)
{

  /* ---- Control the Head Position (camera) ---- */
  PointHeadClientPtr pointHeadClient;
  createHeadClient(pointHeadClient);
  Head_SendAction(pointHeadClient);

  Home_task_state = GRIPPER_POSE;
}

/* =========== Gripper(s) Control =========== */
else if (Home_task_state == GRIPPER_POSE)
{
  /* --- Generate  Gripper Left/Right Client and Control Position --- */
  obj_armsmotion.GripperControl(motion_type);

  Home_task_state = ARM_POSE;
  //Home_task_state = APPROACHING_DONE;
}

/* ========= ARM Motion Planning ========= */
else if (Home_task_state == ARM_POSE)
{
   /* ------ Arm Side Approaching Box Position Control ------ */
    approaching_result = obj_armsmotion.ArmMotionPlanning(Box_pose_left, Box_pose_right, motion_type);
  
  if (first_approaching_exe == ENABLE)
  {
    /* ----- Torso Control ------ */
    obj_armsmotion.TorsoControl(0.25);

    first_approaching_exe = DISABLE;
  }

  if (Box_Pose_update == DISABLE)
  {
    Box_Pose_update = ENABLE;
  }
  else if(Box_Pose_update == VALID)
  {
    
    Box_Pose_update = DISABLE; /* Disable updating the box pose  */

   
    
    if ( approaching_result == EXIT_SUCCESS )
    {
      ROS_INFO("Approaching Done");
      Try_Cnt_Approach = 0;
      return EXIT_SUCCESS;
    }
    else
    {
      Try_Cnt_Approach++;
      ROS_INFO_STREAM("Error: Approaching: " << Try_Cnt_Approach);
    }
  } 
}
 if (Home_task_state == APPROACHING_DONE)
 {
  ROS_INFO("Approaching Done");
  Try_Cnt_Approach = 0;
  return EXIT_SUCCESS;
 }
return EXIT_FAILURE;
}





/* ============================================================
* Fucntion Name: obstacle_pose
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_ik_tiago::obstacle_pose(const geometry_msgs::PoseStamped::Ptr& table_pose)
{

  //ROS_INFO("Table Position");
  
  /* --- get the position/Rotation --- */
  Obstacle_msg_pose.pose.position.x     = table_pose->pose.position.x;
  Obstacle_msg_pose.pose.position.y     = table_pose->pose.position.y;
  Obstacle_msg_pose.pose.position.z     = table_pose->pose.position.z;
  Obstacle_msg_pose.pose.orientation.x  = table_pose->pose.orientation.x;
  Obstacle_msg_pose.pose.orientation.y  = table_pose->pose.orientation.y;
  Obstacle_msg_pose.pose.orientation.z  = table_pose->pose.orientation.z;
  Table_Pose_update = true;
}

/* ============================================================
* Fucntion Name: obstacle_dimension
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_ik_tiago::obstacle_dimension(const geometry_msgs::PoseStamped::Ptr& table_dimension)
{

  //ROS_INFO("Table Dimension");
  
  /* --- get the position/Rotation --- */
  Obstacle_msg_dim.pose.position.x     = table_dimension->pose.position.x;
  Obstacle_msg_dim.pose.position.y     = table_dimension->pose.position.y;
  Obstacle_msg_dim.pose.position.z     = table_dimension->pose.position.z;
  Obstacle_msg_dim.pose.orientation.x  = table_dimension->pose.orientation.x;
  Obstacle_msg_dim.pose.orientation.y  = table_dimension->pose.orientation.y;
  Obstacle_msg_dim.pose.orientation.z  = table_dimension->pose.orientation.z;
  Dim_Pose_update = true;
  
}

/* ============================================================
* Fucntion Name: object_pose
* Description:   

* Inputs:
* Outputs:
============================================================== */
void icr_ik_tiago::object_pose(const icaros_object_rcg::icr_msg_box::Ptr& box_pose)
{

  //ROS_INFO("Box Planning");
  char** argv = 0;
  std::string arm_name = "left";

  /* --- atof (coverting string to double): double atof (const char* str); --- */
  geometry_msgs::PoseStamped goal_pose;
  goal_pose.header.frame_id = "base_footprint";

    /* --- get the position/Rotation --- */
    //goal_pose.pose.position.x = box_pose->Left_box_pose.position.x;
    //goal_pose.pose.position.y = box_pose->Left_box_pose.position.y;
    //goal_pose.pose.position.z = box_pose->Left_box_pose.position.z;
    //goal_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(box_pose->Left_box_pose.orientation.x, box_pose->Left_box_pose.orientation.y, box_pose->Left_box_pose.orientation.z);


    //Box_pose.pose.position.x = box_pose->Left_box_pose.position.x;
    //Box_pose.pose.position.y = box_pose->Left_box_pose.position.y;
    //Box_pose.pose.position.z = box_pose->Left_box_pose.position.z;
    //Box_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(box_pose->Left_box_pose.orientation.x, box_pose->Left_box_pose.orientation.y, box_pose->Left_box_pose.orientation.z);
    //Box_Pose_update = true;

  if (Box_Pose_update == ENABLE)
  {
    Box_pose_left.pose.position.x = box_pose->Left_box_pose.position.x;
    Box_pose_left.pose.position.y = box_pose->Left_box_pose.position.y;
    Box_pose_left.pose.position.z = box_pose->Left_box_pose.position.z;
    Box_pose_left.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(box_pose->Left_box_pose.orientation.x, box_pose->Left_box_pose.orientation.y, box_pose->Left_box_pose.orientation.z);
    
    Box_pose_right.pose.position.x = box_pose->Right_box_pose.position.x;
    Box_pose_right.pose.position.y = box_pose->Right_box_pose.position.y;
    Box_pose_right.pose.position.z = box_pose->Right_box_pose.position.z;
    Box_pose_right.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(box_pose->Right_box_pose.orientation.x, box_pose->Right_box_pose.orientation.y, box_pose->Right_box_pose.orientation.z);

    Box_Pose_update = VALID;
  }
}



int keep_running = 1;
/* ============================================================
* Fucntion Name: object_pose
* Description:   

* Inputs:
* Outputs:
============================================================== */

void SigintHandler(int sig)
{
  keep_running = 0;
}


#define INITIAL_MODE      0x00
#define APPROACHING_MODE  0x01
#define TASK_MODE         0x02
#define SHUTDOWN_MODE     0x03
#define SAFETY_MODE       0x04

#define Motion1_OPEN_LOCK      0x00
#define Motion2_OPEN_LID       0x01
#define Motion3_GRASPING_RACK  0x03

#define MOTOIN_1_SUCCESS    0x00
#define MOTOIN_1_INPROGRESS 0x01
#define MOTOIN_2_SUCCESS    0x02
#define MOTOIN_2_INPROGRESS 0x03
#define MOTOIN_3_SUCCESS    0x04
#define MOTOIN_3_INPROGRESS 0x05

#define TRY_COUNTER_APPROACHING 0x0A

int Current_System_Mode = INITIAL_MODE;
int Pre_System_Mode     = INITIAL_MODE;

//int Motion_type       = Motion1_OPEN_LOCK;
int Motion_type         = Motion2_OPEN_LID;
int Motion_status       = MOTOIN_1_INPROGRESS;
/* ============================================================
* Fucntion Name: 
* Description:  System Modes:
                1- Initial Mode
                2- Aproaching Mode (Object rec.)
                3- Task Mode (Force/Position Control)
                4- Shutdown End Mission Mode
                5- Safety Mode
* Inputs:
* Outputs:
============================================================== */
void icr_ik_tiago::run()
{
  _rate = 10;

  ros::Rate loopRate(_rate);
  
  double halfPeriod = 0.5*1.0/_rate;

  int return_value = EXIT_FAILURE;

  bool anySubscriber = 1;

  impedance_controller obj_IMDController;
  std::string moveit_group = "both_arms_torso";
  moveit::planning_interface::MoveGroupInterface group_arm_torso(moveit_group);
    
  loopRate.sleep();

  /* ----- Signal Function ----- */
  signal(SIGINT, SigintHandler);

  /* ======= Main Loop  ======= */ 
  while ( ros::ok() && keep_running == 1)
  {
  
  #if 1

    /* *************** Initial Mode  **************** */
    if (Current_System_Mode ==  INITIAL_MODE)
    {
      /* Initial Checking System 
        1- Checking: Communication
        2- 
      */
      //ROS_INFO_STREAM("anySubscriber" << anySubscriber );
      if ( !_enabled && anySubscriber )
      {
        start();
        ROS_INFO("Got to Approaching Mode");
        Pre_System_Mode     = Current_System_Mode;
        Current_System_Mode = APPROACHING_MODE;
      }
      else if ( _enabled && !anySubscriber )
      {
        stop();
        ROS_INFO("Error Initial Mode");
        Pre_System_Mode     = Current_System_Mode;
        Current_System_Mode = SAFETY_MODE;
      }      
    }

    /* ************* Approaching Mode  ************** */
    else if (Current_System_Mode == APPROACHING_MODE)
    {
      if (return_value != EXIT_SUCCESS)
      {
        return_value = Approaching(Motion_type);
        if (Try_Cnt_Approach == TRY_COUNTER_APPROACHING) /* After TRY_COUNTER_APPROACHING times trying : Chnage Mode to Wait_Safety Mode*/
        {
          
          Pre_System_Mode     = Current_System_Mode;
          Current_System_Mode = SAFETY_MODE;
        }
      }
      else
      {
        ROS_INFO("Got to Task Mode");
        Pre_System_Mode     = Current_System_Mode;
        Current_System_Mode = TASK_MODE;
      }
    }
    
    /* ************** Task Mode  **************** */
    else if (Current_System_Mode == TASK_MODE)
    {
      
            

    }

    /* ************* Safety Mode  *************** */
    else if (Current_System_Mode ==  SAFETY_MODE)
    {
      if (Pre_System_Mode == INITIAL_MODE)
      {
        throw std::runtime_error("Safety Error: Initial Mode");
      }
      else if (Pre_System_Mode == APPROACHING_MODE)
      {
        throw std::runtime_error("Safety Error: Approaching Mode");
      }
      else if (Pre_System_Mode == TASK_MODE)
      {
        throw std::runtime_error("Safety Error: Task Execution Mode ");
      }    
    }

    /* ************ Shutdown Mode  ************* */
    else if (Current_System_Mode ==  SHUTDOWN_MODE)
    {



    }


    /* ---------------- Motion Selection ------------------
     Harmony includes Three main motions: 
     1- Open the Lock
     2- Open the Lid
     3- Grasping the Rack
    ------------------------------------------------------ */
    if (Motion_status == MOTOIN_1_SUCCESS)
    {
      Motion_type   = Motion2_OPEN_LID;
      Motion_status = MOTOIN_2_INPROGRESS;
    }
    else if (Motion_status == MOTOIN_2_SUCCESS)
    {
      Motion_type   = Motion3_GRASPING_RACK;
      Motion_status = MOTOIN_2_INPROGRESS;
    }
    else if (Motion_status == MOTOIN_3_SUCCESS)
    {
      /* Go to Home Position */
    }
    
#endif


    //check for subscriber's callbacks
    _cbQueue.callAvailable(ros::WallDuration(halfPeriod));

    //check for subscriber's callbacks
    _cbtableQueue.callAvailable(ros::WallDuration(halfPeriod));

    loopRate.sleep();
  }
  
    ROS_INFO("Icaros Controller Stop ............... ");

    /* ----- Stop Navigation ------ */
    //Base_SendAction("STOP_NAV");
    ROS_INFO("STOP Navigation");

    /* ----- Stop Head Manager ------ */
    //HeadManagerDsiable_SendAction(HeadManager, DISABLE);
    ROS_INFO("STOP Head Manager");

    ros::shutdown();








      #if 0
       _pubGripperPose  = _pnh.advertise<trajectory_msgs::JointTrajectory>("/gripper_left_controller/command", 1000);
  _pubTorsoPose = _pnh.advertise<trajectory_msgs::JointTrajectory>("/torso_controller/command", 1000); 
    trajectory_msgs::JointTrajectory  gripper;
    gripper.header.seq = 0;
    gripper.header.frame_id = "";
    
    gripper.joint_names.push_back("gripper_left_left_finger_joint");
    gripper.joint_names.push_back("gripper_left_right_finger_joint");

    //gripper.joint_names.resize(1,"gripper_left_left_finger_joint");
    //gripper.joint_names.resize(1,"gripper_left_right_finger_joint");
    gripper.points.resize(1);
    gripper.points[0].positions.resize(2);

    gripper.points[0].positions[0] = 0.00;  /* Max 0.04  Min 0.00*/
    gripper.points[0].positions[1] = 0.00;

    gripper.points[0].velocities.resize(2);
    gripper.points[0].velocities[0] = 0.0;
    gripper.points[0].velocities[1] = 0.0;

    //gripper.points[0].accelerations.resize(2);
    //gripper.points[0].accelerations[0] = 0.00;
    //gripper.points[0].accelerations[1] = 0.00;

    //gripper.points[0].effort.resize(2);
    //gripper.points[0].effort[0] = 0.00;
    //gripper.points[0].effort[1] = 0.00;

    gripper.points[0].time_from_start.sec = 1;
    gripper.points[0].time_from_start.nsec = 0; 
    //gripper.points[0].time_from_start = ros::Duration(1.0);
    //gripper.header.stamp = ros::Time::now() + ros::Duration();

    _pubGripperPose.publish(gripper);
    ROS_INFO("Publish Gripper");
#endif
#if 0
    trajectory_msgs::JointTrajectory  torso;
    torso.header.seq = 0;
    torso.header.frame_id = "";
    torso.joint_names.push_back("torso_lift_joint");
    torso.points.resize(1);
    torso.points[0].positions.resize(1);
    torso.points[0].positions[0] = 0.15;

    torso.points[0].velocities.resize(1);
    torso.points[0].velocities[0] = 0.0;

    torso.points[0].accelerations.resize(1);  
    torso.points[0].accelerations[0] = 0.0;

    torso.points[0].effort.resize(1);  
    torso.points[0].effort[0] = 0;

    torso.points[0].time_from_start.sec = 1;
    torso.points[0].time_from_start.nsec = 0;
    //torso.points[0].time_from_start = ros::Duration(1);
    //torso.header.stamp = ros::Time::now() + ros::Duration();


    ROS_INFO("Publish Torso");
    _pubTorsoPose.publish(torso);
    ROS_INFO("Publish Torso");
#endif
  
}