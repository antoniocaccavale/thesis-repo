/* ==================================== main ================================
************************************** ICAROS ******************************
All Rights are reserved By
University of Naples Federico II

Author: Mohammad Hossein Hamedani
Emai:
Date:
Compiler:gnu++/catkin build

Revision History
-----------------------------------
V01: 2022/02/04  Initial Version

=============================================================================*/

/* Including General C++ Header(s) */
#include <exception>
#include <string>
#include <boost/shared_ptr.hpp>

/* Including ROS Header(s) */
#include <ros/ros.h>
#include <actionlib/client/simple_action_client.h>
#include <control_msgs/FollowJointTrajectoryAction.h>
#include <ros/topic.h>

/* Including the Icaros Header Files */
#include "icr_ik_tiago.h"
#include "icr_Motionplanning_arms.h"

/* ============================================================
* Fucntion Name: main
* Description:  Main Function

* Inputs:
* Outputs:
============================================================== */
int main(int argc, char**  argv)
{

    /* --- Init Ros System --- */
    ros::init(argc, argv, "Icaros_Controller_Node");  /* Create "Icaros_Controller_Node" node */

    ROS_INFO("Starting Icaros Controller Node ...");
    
    ros::NodeHandle nh, pnh("~"), nh_1;
    ros::AsyncSpinner spinner(1);
    icr_ik_tiago obj_ikdualarm(nh, pnh, nh_1);

    spinner.start();


    obj_ikdualarm.run();

    return EXIT_SUCCESS;
}