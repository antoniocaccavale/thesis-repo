/* ==================================== main ================================
************************************** ICAROS ******************************
                            All Rights are reserved By
                         University of Naples Federico II

Author: Mohammad Hossein Hamedani
Email:
Date:
Compiler:gnu++/catkin build

Revision History
-----------------------------------
V01: 2022/02/04  Initial Version

=============================================================================*/

#include <ros/ros.h>

#include <tf/transform_broadcaster.h>

#include "std_msgs/String.h"

#include "icr_Motionplanning_arms.h"

#include <icaros_object_rcg/icr_msg_box.h>

//ROS headers
#include <actionlib/client/simple_action_client.h>
#include <play_motion_msgs/PlayMotionAction.h>
#include <ros/package.h>
#include <actionlib/client/simple_action_client.h>
#include <geometry_msgs/PointStamped.h>
#include <control_msgs/PointHeadAction.h>
#include <control_msgs/FollowJointTrajectoryAction.h>

// C++ standard headers
#include <cstdlib>
#include <yaml-cpp/yaml.h>

/* ---- PAL Library ----- */


/* ----- GLOBAL VARIABLES ------ */


/* ------- Definitions -------- */
#define TEST_RUN 0

/* Gripper Two Fingers Max 0.04  Min 0.00*/
#define M1_LF_LF_GRIPPER_POS    0.00
#define M1_LF_RT_GRIPPER_POS    0.00
#define M1_RT_LF_GRIPPER_POS    0.00
#define M1_RT_RT_GRIPPER_POS    0.00

#define M2_LF_LF_GRIPPER_POS    0.04
#define M2_LF_RT_GRIPPER_POS    0
#define M2_RT_LF_GRIPPER_POS    0
#define M2_RT_RT_GRIPPER_POS    0.04

#define HOME_POS  0x01
#define TABLE_POS 0x02

#define FRAME_POSE_TELPRANCE  0.3  

#define NOT_VALID false
#define VALID     true

#define BOX_POSE_VALID      0x00
#define DEPTH_X_NOT_VALID   0x01
#define WIGHT_Y_NOT_VALID   0x02
#define HEIGHT_Z_NOT_VALID  0x03



#define Motion1_OPEN_LOCK      0x00
#define Motion2_OPEN_LID       0x01

#define ARM_LEFT  0x00
#define ARM_RIGHT 0x01
#define BOTH_ARMS 0x02
typedef struct 
{
  double left_arm_x = 0;
  double left_arm_y = 0;
  double left_arm_z = 0;
  double left_arm_a = 0;
  double left_arm_b = 0;
  double left_arm_c = 0;

  double right_arm_x = 0;
  double right_arm_y = 0;
  double right_arm_z = 0;
  double right_arm_a = 0;
  double right_arm_b = 0;
  double right_arm_c = 0;
}struct_arm_pose;

struct_arm_pose Arm_Pose;




/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
icr_Motionplanning_arms::icr_Motionplanning_arms(/* args */)
{

}

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
icr_Motionplanning_arms::~icr_Motionplanning_arms()
{

}



/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_Motionplanning_arms::TorsoControl(double lift_value)
{
  /* --- Generate  Gripper Left/Right Client and Control Position --- */
  torso_control_client_ptr torso_client;
  torso_control_client_ptr actionClient;
  
  ROS_INFO("Creating action client to torso controller ...");

  actionClient.reset( new torso_control_client("/torso_controller/follow_joint_trajectory") );

  int iterations = 0, max_iterations = 3;
  // Wait for head controller action server to come up
  while( !actionClient->waitForServer(ros::Duration(2.0)) && ros::ok() && iterations < max_iterations )
  {
    ROS_DEBUG("Waiting for the torso server to come up");
    ++iterations;
  }

  if ( iterations == max_iterations )
    throw std::runtime_error("Error in create torso client: torso controller action server not available");
  
  TorsoSendAction(actionClient, lift_value); 
}

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_Motionplanning_arms::TorsoSendAction(torso_control_client_ptr torso_client, double lift_value)
{
  control_msgs::FollowJointTrajectoryGoal goal_torso;
  ROS_INFO("torso joint");
  goal_torso.trajectory.joint_names.push_back("torso_lift_joint");
  //goal_torso.trajectory.header.frame_id = "base_footprint";
  goal_torso.trajectory.points.resize(1);
  goal_torso.trajectory.points[0].positions.resize(1);
  
  goal_torso.trajectory.points[0].positions[0] = lift_value;  /* Max 0.35  Min 0.00*/

  goal_torso.trajectory.points[0].velocities.resize(1);
  goal_torso.trajectory.points[0].velocities[0] = 0.1;

  goal_torso.trajectory.points[0].time_from_start.sec = 2;
  goal_torso.trajectory.points[0].time_from_start.nsec = 0;

  //goal_torso.trajectory.points[0].time_from_start = ros::Duration(0.1);
  //goal_torso.trajectory.header.stamp = ros::Time::now();
  torso_client->sendGoal(goal_torso);

  ROS_INFO("Waiting for result ...");
  bool actionOk = torso_client->waitForResult(ros::Duration(90.0));

  actionlib::SimpleClientGoalState state = torso_client->getState();

  if (actionOk )
    ROS_INFO_STREAM("Action Torso finished successfully with state: " << state.toString());
  else
    ROS_ERROR_STREAM("Action Torso failed with state: " << state.toString());
}



/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_Motionplanning_arms::GripperControl(int motion_type)
{
  /* --- Generate  Gripper Left/Right Client and Control Position --- */
  gripper_control_client_ptr gripper_left_client;
  gripper_control_client_ptr gripper_right_client;

  createGripperClient(gripper_left_client, "gripper_left_controller");    /* Creat Action Client for Left Gripper  */
  createGripperClient(gripper_right_client, "gripper_right_controller");  /* Creat Action Client for Right Gripper  */

  Left_Gripper_SendAction(gripper_left_client, motion_type);    /* Send Action goal for the Left Grippers */
  Right_Gripper_SendAction(gripper_right_client, motion_type);  /* Send Action goal for the Right Gripper */
}


/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_Motionplanning_arms::createGripperClient(gripper_control_client_ptr& action_client , 
                                           const std::string gripper_controller_name)
{
    ROS_INFO ("Creating Action Client to %s ...", gripper_controller_name.c_str());

    std::string action_client_name = "/" + gripper_controller_name + "/follow_joint_trajectory";
    action_client.reset(new gripper_control_client(action_client_name));

    int iterations = 0, max_iterations = 3;
    /* Wiat for arm controller action server to come up */
    while (!action_client->waitForServer(ros::Duration(2.0)) && ros::ok() && iterations < max_iterations)
    {
        ROS_DEBUG("waiting for the gripper_controller_actoin server to come up");
        ++iterations;
    }
    if(iterations == max_iterations)
    {
        throw std::runtime_error ("Error in createGripperClient: gripper controller action server not available");
    }
}


/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_Motionplanning_arms::Left_Gripper_SendAction(gripper_control_client_ptr Left_gripper_client, int motion_type)
{
  control_msgs::FollowJointTrajectoryGoal goal_gripper;
  goal_gripper.trajectory.joint_names.push_back("gripper_left_left_finger_joint");
  goal_gripper.trajectory.joint_names.push_back("gripper_left_right_finger_joint");
  goal_gripper.trajectory.points.resize(1);
  goal_gripper.trajectory.points[0].positions.resize(2);

  if (motion_type == Motion1_OPEN_LOCK)
  {
    goal_gripper.trajectory.points[0].positions[0] = M1_LF_LF_GRIPPER_POS;  /* Max 0.04  Min 0.00*/
    goal_gripper.trajectory.points[0].positions[1] = M1_LF_RT_GRIPPER_POS;
  }
  else if (motion_type == Motion2_OPEN_LID)
  {
    goal_gripper.trajectory.points[0].positions[0] = M1_LF_LF_GRIPPER_POS;  /* Max 0.04  Min 0.00*/
    goal_gripper.trajectory.points[0].positions[1] = M1_LF_RT_GRIPPER_POS;
  }

  goal_gripper.trajectory.points[0].velocities.resize(2);
  goal_gripper.trajectory.points[0].velocities[0] = 0.1;
  goal_gripper.trajectory.points[0].velocities[1] = 0.1;
  goal_gripper.trajectory.points[0].time_from_start.sec = 1;
  goal_gripper.trajectory.points[0].time_from_start.nsec = 0;
 
  //goal_gripper.trajectory.points[0].accelerations.resize(2);
  //goal_gripper.trajectory.points[0].accelerations[0] = 0.00;
  //goal_gripper.trajectory.points[0].accelerations[1] = 0.00;
  //goal_gripper.trajectory.points[0].time_from_start = ros::Duration(0.1);
  //goal_gripper.trajectory.header.stamp = ros::Time::now();
  Left_gripper_client->sendGoal(goal_gripper);


  #if 1
  ROS_INFO("Waiting for result Left Gripper Action ...");
  bool actionOk = Left_gripper_client->waitForResult(ros::Duration(90.0));

  actionlib::SimpleClientGoalState state = Left_gripper_client->getState();

  if (actionOk )
    ROS_INFO_STREAM("Action Left Gripper finished successfully with state: " << state.toString());
  else
    ROS_ERROR_STREAM("Action Left Gripper failed with state: " << state.toString());
  #endif 


  #if 0
  ROS_INFO("Waiting for result Left Gripper Action ...");
  /* Wait for trajectory execution */

  while (!(Left_gripper_client->getState().isDone()) && ros::ok())
  {
    ros::Duration(4).sleep(); /* Sleep for four seconds */
  }
  bool action_Gripper_Ok = Left_gripper_client->waitForResult(ros::Duration(90.0));
  actionlib::SimpleClientGoalState state_gripper = Left_gripper_client->getState();
  if ( action_Gripper_Ok )
  {
    ROS_INFO_STREAM("Action Left Gripper finished successfully with state: " << state_gripper.toString());
  }  
  else
  {
    ROS_ERROR_STREAM("Action Left Gripper failed with state: " << state_gripper.toString());
  }
  #endif
}

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_Motionplanning_arms::Right_Gripper_SendAction(gripper_control_client_ptr Right_gripper_client, int motion_type)
{
  control_msgs::FollowJointTrajectoryGoal goal_gripper;
  goal_gripper.trajectory.joint_names.push_back("gripper_right_left_finger_joint");
  goal_gripper.trajectory.joint_names.push_back("gripper_right_right_finger_joint");
  goal_gripper.trajectory.points.resize(1);
  goal_gripper.trajectory.points[0].positions.resize(2);

  if (motion_type == Motion1_OPEN_LOCK)
  {
    goal_gripper.trajectory.points[0].positions[0] = M1_RT_LF_GRIPPER_POS;  /* Max 0.04  Min 0.00*/
    goal_gripper.trajectory.points[0].positions[1] = M1_RT_RT_GRIPPER_POS;
  }
  else if (motion_type == Motion1_OPEN_LOCK)
  {
    goal_gripper.trajectory.points[0].positions[0] = M1_RT_LF_GRIPPER_POS;  /* Max 0.04  Min 0.00*/
    goal_gripper.trajectory.points[0].positions[1] = M1_RT_RT_GRIPPER_POS;
  }

  goal_gripper.trajectory.points[0].velocities.resize(2);
  goal_gripper.trajectory.points[0].velocities[0] = 0.0;
  goal_gripper.trajectory.points[0].velocities[1] = 0.0;
  goal_gripper.trajectory.points[0].time_from_start.sec = 1;
  goal_gripper.trajectory.points[0].time_from_start.nsec = 0;
  //goal_gripper.trajectory.points[0].time_from_start = ros::Duration(0.1);
  //goal_gripper.trajectory.header.stamp = ros::Time::now();
  Right_gripper_client->sendGoal(goal_gripper);


  ROS_INFO("Waiting for result Right Gripper Action ...");
  bool actionOk = Right_gripper_client->waitForResult(ros::Duration(90.0));

  actionlib::SimpleClientGoalState state = Right_gripper_client->getState();

  if (actionOk )
    ROS_INFO_STREAM("Action Right Gripper finished successfully with state: " << state.toString());
  else
    ROS_ERROR_STREAM("Action Right Gripper failed with state: " << state.toString());




  #if 0
  ROS_INFO("Waiting for result Right Gripper Action...");
  /* Wait for trajectory execution */
  while (!(Right_gripper_client->getState().isDone()) && ros::ok())
  {
    ros::Duration(4).sleep(); /* Sleep for four seconds */
  }
  bool action_Gripper_Ok = Right_gripper_client->waitForResult(ros::Duration(90.0));
  actionlib::SimpleClientGoalState state_gripper = Right_gripper_client->getState();
  if ( action_Gripper_Ok )
  {
    ROS_INFO_STREAM("Action Right Gripper finished successfully with state: " << state_gripper.toString());
  }  
  else
  {
    ROS_ERROR_STREAM("Action Right Gripper failed with state: " << state_gripper.toString());
  }
  #endif
}




/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void icr_Motionplanning_arms::ARM_Homeposition()
{
  actionlib::SimpleActionClient<play_motion_msgs::PlayMotionAction> client("/play_motion", true);
  ROS_INFO("Waiting for Action Server ...");
  client.waitForServer();
  play_motion_msgs::PlayMotionGoal goal;
  goal.motion_name = "home";
  goal.skip_planning = true;
  goal.priority = 0;
  ROS_INFO_STREAM("Sending goal with motion: " << goal.motion_name);
  client.sendGoal(goal);
  ROS_INFO("Waiting for result ...");
  bool actionOk = client.waitForResult(ros::Duration(90.0));
  actionlib::SimpleClientGoalState state = client.getState();
  if ( actionOk )
  {
    ROS_INFO_STREAM("Action finished successfully with state: " << state.toString());
  } 
  else
  {
    ROS_ERROR_STREAM("Action failed with state: " << state.toString());
  }
}
 
/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
float rond(float var)
{
    // 37.66666 * 100 =3766.66
    // 3766.66 + .5 =3767.16    for rounding off value
    // then type cast to int so value is 3767
    // then divided by 100 so the value converted into 37.67
    float value = (int)(var * 100);
    return (float)value / 100;
}




geometry_msgs::PoseStamped Left_Arm_pose;
geometry_msgs::PoseStamped Right_Arm_pose;
std::string moveit_group = "both_arms_torso";
geometry_msgs::PoseStamped Left_Side_Box;
geometry_msgs::PoseStamped Right_Side_Box;

/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
int icr_Motionplanning_arms::ArmMotionPlanning(geometry_msgs::PoseStamped Box_pose_left, geometry_msgs::PoseStamped Box_pose_right, int motion_type)
{

  char** argv = 0;
  moveit::planning_interface::MoveGroupInterface::Plan my_plan;
  moveit::planning_interface::MoveGroupInterface group_arm_torso(moveit_group);
  /* ---- pose left and right of the front surface of the Box ----- 
     *----------*
     |          |
     |          |
      -----------
  */
  Left_Side_Box  = Box_pose_left;
  Right_Side_Box = Box_pose_right;


//  ROS_INFO("Table pose ");
//  ROS_INFO_STREAM("\tX Table = " << Obstacle_msg_pose.pose.position.x);
//  ROS_INFO_STREAM("\tY Table = " << Obstacle_msg_pose.pose.position.y);
//  ROS_INFO_STREAM("\tZ Table = " << Obstacle_msg_pose.pose.position.z);

//  ROS_INFO("Table dime ");
//  ROS_INFO_STREAM("\tDim 1 = " << Obstacle_msg_dim.pose.position.x);
//  ROS_INFO_STREAM("\tDim 2 = " << Obstacle_msg_dim.pose.position.y);
//  ROS_INFO_STREAM("\tDim 3 = " << Obstacle_msg_dim.pose.position.z);

  
  /* ======== Start Motion Planning for approaching to the Box ========= */

  /* Display the Box Position */
  ROS_INFO("Box Pose Left");
  ROS_INFO_STREAM("\tX Left Box = " << Box_pose_left.pose.position.x);
  ROS_INFO_STREAM("\tY Left Box = " << Box_pose_left.pose.position.y);
  ROS_INFO_STREAM("\tZ Left Box = " << Box_pose_left.pose.position.z);

  ROS_INFO("Box Pose Right");
  ROS_INFO_STREAM("\tX Right Box = " << Box_pose_right.pose.position.x);
  ROS_INFO_STREAM("\tY Right Box = " << Box_pose_right.pose.position.y);
  ROS_INFO_STREAM("\tZ Right Box = " << Box_pose_right.pose.position.z);


  /* ------- Valid Box position  -------- */
#if 1
  int box_valid_error = 0x00;
  box_valid_error = Box_Pose_Verify();
  if ( BOX_POSE_VALID != box_valid_error)
  {
    ROS_INFO_STREAM("\tBox Position is Not Valid " << box_valid_error);
    //ROS_INFO("Box Position is Not Valid");
    //throw std::runtime_error("Error execution plan: Box not found");
    return EXIT_FAILURE;
  }
  else
  {
    ROS_INFO("Box Position is Valid");
  }
#endif

#if 1
  /* ------- Start Approaching  -------- */
  if (motion_type == Motion1_OPEN_LOCK)
  {
    /* ----- Adjusting the Z Position ---- */
    ROS_INFO(" Intial motion ");
    Set_initial_motion(motion_type);
    Approaching_to_initial_pose(motion_type);



  }
  else if(motion_type == Motion2_OPEN_LID)
  {
    /* ----- Adjusting the Z Position ---- */
    Pose_Z_Arm(motion_type);

    /* ----- Adjusting the X Position ---- */
    Pose_X_Arm(motion_type);

    /* ----- Adjusting the Y Position ---- */
    Pose_Y_Arm (motion_type);
  }
  
#endif

  

  /* ----- Display Current Position of the E-E ----- */
  ROS_INFO("Current Position Left E-E");
  ROS_INFO_STREAM("\tX Left E-E = " << group_arm_torso.getCurrentPose("arm_left_tool_link").pose.position.x);
  ROS_INFO_STREAM("\tY Left E-E = " << group_arm_torso.getCurrentPose("arm_left_tool_link").pose.position.y);
  ROS_INFO_STREAM("\tZ Left E-E = " << group_arm_torso.getCurrentPose("arm_left_tool_link").pose.position.z);

  ROS_INFO("Current Position Right E-E");
  ROS_INFO_STREAM("\tX Right E-E = " << group_arm_torso.getCurrentPose("arm_right_tool_link").pose.position.x);
  ROS_INFO_STREAM("\tY Right E-E = " << group_arm_torso.getCurrentPose("arm_right_tool_link").pose.position.y);
  ROS_INFO_STREAM("\tZ Right E-E = " << group_arm_torso.getCurrentPose("arm_right_tool_link").pose.position.z);


return EXIT_SUCCESS;
}


/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
int  icr_Motionplanning_arms::Box_Pose_Verify(void)
{

  /* Table Height = 70 - 72 cm*/
  /* Karolinska Box (width) = 33cm , Height = 30cm, Depth = 27cm*/
  /* Karolinska lock Z = 22cm, Width = 33/2cm Middle of the box */
  
  int box_valid_status = !BOX_POSE_VALID;
  /* X: Depth Checking */
  if (Left_Side_Box.pose.position.x  > 0.5  && 
      Left_Side_Box.pose.position.x  < 0.85    && 
      Right_Side_Box.pose.position.x > 0.5  && 
      Right_Side_Box.pose.position.x < 0.85)
  {
     box_valid_status = BOX_POSE_VALID;
  }
  else
  {
    return DEPTH_X_NOT_VALID;
  }

  /* Y: Width Checking */
  if (Left_Side_Box.pose.position.y  < 0.25  && 
      Left_Side_Box.pose.position.y  > 0      &&
      Right_Side_Box.pose.position.y < 0      && 
      Right_Side_Box.pose.position.y > -0.25)
  {  
      if ( (Left_Side_Box.pose.position.y - Right_Side_Box.pose.position.y) < 0.4)
      {
        box_valid_status = BOX_POSE_VALID;
      }
      else
      {
        return WIGHT_Y_NOT_VALID;
      }
  }
  else
  {
    return WIGHT_Y_NOT_VALID;
  }

  /* Z: Height Checking */
  if (Left_Side_Box.pose.position.z  > 0.6 && 
      Left_Side_Box.pose.position.z  < 1.2 &&
      Right_Side_Box.pose.position.z > 0.6 && 
      Right_Side_Box.pose.position.z < 1.2)
  {
    box_valid_status = BOX_POSE_VALID;
  }
  else
  {
    return HEIGHT_Z_NOT_VALID;
  }
  return box_valid_status;
}


/* ============================================================
* Fucntion Name: TorsoMotionPlanning
* Description:   Torso Motion Control
* Inputs:
* Outputs:
============================================================== */
void icr_Motionplanning_arms::Set_initial_motion(int motion_type)
{
  if ( motion_type == Motion1_OPEN_LOCK)
  {
  
    Left_Arm_pose.pose.position.x = 0.4;  /*  Bigger Than */
    Left_Arm_pose.pose.position.y = Left_Side_Box.pose.position.y + 0.1;   //0.2
    Left_Arm_pose.pose.position.z = Left_Side_Box.pose.position.z + 0.1;
    Left_Arm_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(0, 0, -0.78);

 
    Right_Arm_pose.pose.position.x = 0.4 ;  /* Bigger Than 0.5*/
    Right_Arm_pose.pose.position.y = (Right_Side_Box.pose.position.y + Left_Side_Box.pose.position.y)/2;
    Right_Arm_pose.pose.position.z = Right_Side_Box.pose.position.z - 0.1 ;  /*0.7 to 1.1*/
    Right_Arm_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(0, 0, 0);    /*0, 0.1, 0.2, 0.3 upper body*/
    
  }
  else if(motion_type == Motion2_OPEN_LID)
  {
    
    Left_Arm_pose.pose.position.x = 0.4;
    Left_Arm_pose.pose.position.y = Left_Side_Box.pose.position.y + 0.1;
    Left_Arm_pose.pose.position.z = (Left_Side_Box.pose.position.z);
    Left_Arm_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(1.57, 0, 0);
    
    Right_Arm_pose.pose.position.x = 0.4;
    Right_Arm_pose.pose.position.y = Right_Side_Box.pose.position.y - 0.1;
    Right_Arm_pose.pose.position.z = (Right_Side_Box.pose.position.z);
    Right_Arm_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(1.57, 0, 0);
  }
  motion_planning_contorl (BOTH_ARMS);
  //motion_planning_contorl (ARM_LEFT);
  //motion_planning_contorl (ARM_RIGHT);
}


/* ============================================================
* Fucntion Name: TorsoMotionPlanning
* Description:   Torso Motion Control
* Inputs:
* Outputs:
============================================================== */
void icr_Motionplanning_arms::Approaching_to_initial_pose(int motion_type)
{
  std::string moveit_group_selection = "both_arms_torso";
  moveit::planning_interface::MoveGroupInterface group_arm_torso(moveit_group_selection);
  geometry_msgs::PoseStamped current_left_arm_pose;
  geometry_msgs::PoseStamped current_right_arm_pose;
  current_left_arm_pose   = group_arm_torso.getCurrentPose("arm_left_tool_link");
  current_right_arm_pose  = group_arm_torso.getCurrentPose("arm_right_tool_link");
  if ( motion_type == Motion1_OPEN_LOCK)
  {
    Left_Arm_pose.pose.position.x   = 0.6;
    Left_Arm_pose.pose.position.y   = current_left_arm_pose.pose.position.y;
    Left_Arm_pose.pose.position.z   = current_left_arm_pose.pose.position.z;
    Left_Arm_pose.pose.orientation  = current_left_arm_pose.pose.orientation;

    Right_Arm_pose.pose.position.x  = Right_Side_Box.pose.position.x - 0.05 ;
    Right_Arm_pose.pose.position.y  = current_right_arm_pose.pose.position.y;
    Right_Arm_pose.pose.position.z  = current_right_arm_pose.pose.position.z + 0.1;
    Right_Arm_pose.pose.orientation = current_right_arm_pose.pose.orientation;
    motion_planning_contorl (ARM_LEFT);
    //motion_planning_contorl (ARM_RIGHT);

  }
  else if(motion_type == Motion2_OPEN_LID)
  {
    Left_Arm_pose.pose.position.x   =  (Left_Side_Box.pose.position.x) - 0.1;
    Left_Arm_pose.pose.position.y   = current_left_arm_pose.pose.position.y;
    Left_Arm_pose.pose.position.z   = current_left_arm_pose.pose.position.z;
    Left_Arm_pose.pose.orientation  = current_left_arm_pose.pose.orientation;

    Right_Arm_pose.pose.position.x  = (Right_Side_Box.pose.position.x) - 0.1;
    Right_Arm_pose.pose.position.y  = current_right_arm_pose.pose.position.y;
    Right_Arm_pose.pose.position.z  = current_right_arm_pose.pose.position.z;
    Right_Arm_pose.pose.orientation = current_right_arm_pose.pose.orientation;
    motion_planning_contorl (BOTH_ARMS);

  }
  


}


/* ============================================================
* Fucntion Name: TorsoMotionPlanning
* Description:   Torso Motion Control
* Inputs:
* Outputs:
============================================================== */
void  icr_Motionplanning_arms::motion_planning_contorl (int motion_type)
{
  
  
  std::string moveit_group_selection;

  
  if (motion_type == ARM_LEFT)
  {
    moveit_group_selection = "arm_left";
    //moveit_group_selection = "arm_left_torso";
    Left_Arm_pose.header.frame_id = "base_footprint";
    Right_Arm_pose.header.frame_id = "base_footprint";
  }

  else if(motion_type == ARM_RIGHT)
  { 
    moveit_group_selection = "arm_right";
    //std::string moveit_group_selection = "arm_right_torso";
    Right_Arm_pose.header.frame_id = "base_footprint";
  }

  else if(motion_type == BOTH_ARMS)
  {
    moveit_group_selection = "both_arms_torso";
    Left_Arm_pose.header.frame_id  = "base_footprint";
    Right_Arm_pose.header.frame_id = "base_footprint";
  }

  /* ------ Set motion planning type ------- */
  moveit::planning_interface::MoveGroupInterface group_arm_torso(moveit_group_selection);
  if (motion_type == ARM_LEFT)
  {
    group_arm_torso.setPoseTarget(Left_Arm_pose,"arm_left_tool_link");
  }

  else if(motion_type == ARM_RIGHT)
  { 
    group_arm_torso.setPoseTarget(Right_Arm_pose,"arm_right_tool_link"); 
  }

  else if(motion_type == BOTH_ARMS)
  {
    group_arm_torso.setPoseTarget(Left_Arm_pose,"arm_left_tool_link");
    group_arm_torso.setPoseTarget(Right_Arm_pose,"arm_right_tool_link"); 
  }

  group_arm_torso.setPlannerId("SBLkConfigDefault");
  group_arm_torso.setStartStateToCurrentState();
  group_arm_torso.setMaxVelocityScalingFactor(1.0);
  group_arm_torso.setPoseReferenceFrame("base_footprint");

  /* ------ Set the Maximum time to find the plane ------- */
  moveit::planning_interface::MoveGroupInterface::Plan my_plan;
  group_arm_torso.setPlanningTime(5.0);
  bool success = bool(group_arm_torso.plan(my_plan));
  if (!success)
  {
      throw std::runtime_error("No plan found");
  }
  ROS_INFO_STREAM("Plan found for Motion in" << my_plan.planning_time_ << "seconds");

  /* --------- Execute the plan --------- */
  ros::Time strat = ros::Time::now();
  #if 1
  moveit::planning_interface::MoveItErrorCode e  = group_arm_torso.move(); 
  #else
  moveit::planning_interface::MoveItErrorCode e = group_arm_torso.asyncMove();
  #endif
  
  if(!bool(e))
  {
      throw std::runtime_error("Error execution plan");
  }
  else /* Motion Planning is completed */
  {
    
  }



}
/* ============================================================
* Fucntion Name: TorsoMotionPlanning
* Description:   Torso Motion Control
* Inputs:
* Outputs:
============================================================== */
void  icr_Motionplanning_arms::TorsoMotionPlanning(void)
{
  std::string moveit_torso = "torso";
  moveit::planning_interface::MoveGroupInterface::Plan my_plan;
  moveit::planning_interface::MoveGroupInterface group_torso(moveit_torso);

  geometry_msgs::PoseStamped Solo_Torso;
  
  Solo_Torso.header.frame_id = "base_footprint";
  Solo_Torso.pose.position.x = 0;
  Solo_Torso.pose.position.y = 0;
  Solo_Torso.pose.position.z = 0.5;
  Solo_Torso.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(0, 0, 0);

  group_torso.setPlannerId("SBLkConfigDefault");
  //group_arm_torso.setPlannerId("ESTkConfigDefault");
  group_torso.setStartStateToCurrentState();
  group_torso.setMaxVelocityScalingFactor(1.0);
  group_torso.setPoseReferenceFrame("base_footprint");

  /* ------ Set the Maximum time to find the plane ------- */
  group_torso.setPlanningTime(5.0);
  bool success = bool(group_torso.plan(my_plan));
  if (!success)
  {
      throw std::runtime_error("No plan found");
  }
  ROS_INFO_STREAM("Plan found for Torso Motion Adjusting in" << my_plan.planning_time_ << "seconds");

  /* --------- Execute the plan --------- */
  ros::Time strat = ros::Time::now();

  #if 1
  moveit::planning_interface::MoveItErrorCode e  = group_torso.move(); 
  #else
  moveit::planning_interface::MoveItErrorCode e = group_torso.asyncMove();
  #endif
  
  if(!bool(e))
  {
      throw std::runtime_error("Error execution planfor Torso ");
  }
  else /* Motion Planning is completed */
  {
    
  }
}




/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void  icr_Motionplanning_arms::Pose_Z_Arm (int motion_type)
{
  moveit::planning_interface::MoveGroupInterface::Plan my_plan;
  moveit::planning_interface::MoveGroupInterface group_arm_torso(moveit_group);
double j = -0.1;
//for (int i = 0; i<10; i++)
{
 
j = j + 0.1;

  /* ------- Select the group of joints ------- */
  //std::string moveit_group = "arm_left_torso";
  //std::string moveit_group = "arm_right_torso";
  if ( motion_type == Motion1_OPEN_LOCK)
  {
    Left_Arm_pose.header.frame_id = "base_footprint";
    Left_Arm_pose.pose.position.x = 0.45;  /*  Bigger Than */
    Left_Arm_pose.pose.position.y = 0.3;   //0.2
    Left_Arm_pose.pose.position.z = 1;
    Left_Arm_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(0, 0, -0.78);
    group_arm_torso.setPoseTarget(Left_Arm_pose,"arm_left_tool_link");

    Right_Arm_pose.header.frame_id = "base_footprint";
    Right_Arm_pose.pose.position.x = 0.5 ;  /* Bigger Than 0.5*/
    Right_Arm_pose.pose.position.y = 0.0;
    Right_Arm_pose.pose.position.z = 0.8 ;  /*0.7 to 1.1*/
    Right_Arm_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(0, 0, 0);    /*0, 0.1, 0.2, 0.3 upper body*/
    group_arm_torso.setPoseTarget(Right_Arm_pose,"arm_right_tool_link"); 
  }
  else if(motion_type == Motion2_OPEN_LID)
  {
    Left_Arm_pose.header.frame_id = "base_footprint";
    Left_Arm_pose.pose.position.x = 0.4;
    Left_Arm_pose.pose.position.y = 0.3;
    Left_Arm_pose.pose.position.z = (Left_Side_Box.pose.position.z);
    Left_Arm_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(1.57, 0, 0);
    group_arm_torso.setPoseTarget(Left_Arm_pose,"arm_left_tool_link");

    Right_Arm_pose.header.frame_id = "base_footprint";
    Right_Arm_pose.pose.position.x = 0.4;
    Right_Arm_pose.pose.position.y = -0.3;
    Right_Arm_pose.pose.position.z = (Right_Side_Box.pose.position.z);
    Right_Arm_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(1.57, 0, 0);
    group_arm_torso.setPoseTarget(Right_Arm_pose,"arm_right_tool_link");
  }
  

  //group_arm_torso.setPlannerId("RRTkConfigDefault");
  group_arm_torso.setPlannerId("SBLkConfigDefault");
  //group_arm_torso.setPlannerId("ESTkConfigDefault");
  group_arm_torso.setStartStateToCurrentState();
  group_arm_torso.setMaxVelocityScalingFactor(1.0);
  group_arm_torso.setPoseReferenceFrame("base_footprint");
  


#if 0
moveit_msgs::AttachedCollisionObject attached_object;
attached_object.link_name = "base_footprint";
attached_object.object.header.frame_id = "base_footprint";
attached_object.object.id = "table";
geometry_msgs::Pose table_pose;
table_pose.orientation.w = 1;
table_pose.position.x = 0.4;
table_pose.position.y = 0.0;
table_pose.position.z = 0.6;

shape_msgs::SolidPrimitive primitive;
primitive.type = primitive.BOX;
primitive.dimensions.resize(3);
primitive.dimensions[0] = 0.1;
primitive.dimensions[1] = 0.1;
primitive.dimensions[2] = 0.1;

attached_object.object.primitives.push_back(primitive);
attached_object.object.primitive_poses.push_back(table_pose);
attached_object.object.operation = attached_object.object.ADD;

moveit_msgs::PlanningScene planning_scene;
planning_scene.world.collision_objects.push_back(attached_object.object);
planning_scene.is_diff = true;
ROS_INFO_NAMED("tutorial", "Add an object into the world");
#endif

#if 0
    /* -------- Set the Object Collision -------- */
    moveit::planning_interface::PlanningSceneInterface planning_scene_interface;
    // Collision object
    moveit_msgs::CollisionObject collision_object;
    collision_object.header.frame_id = "base_footprint";
    collision_object.id = "table";

  /* All sahpes are defined to have their bounding boxes centered around 0,0,0 (base_footprint) */
    shape_msgs::SolidPrimitive primitive;
    primitive.type = primitive.BOX;
    primitive.dimensions.resize(3);
    primitive.dimensions[0] = 0.1;
    primitive.dimensions[1] = 1.3;
    primitive.dimensions[2] = 0.01;

    /* The X, Y, Z dimensions are the length of the corresponding sides of the Box */
    geometry_msgs::Pose table_pose;
    table_pose.orientation.w = 1;
    table_pose.position.x = 0.4;
    table_pose.position.y = 0;
    table_pose.position.z = 0.6;

    //table_pose.orientation.w = 1;
    //table_pose.position.x = Obstacle_msg_pose.pose.position.x;
    //table_pose.position.y = Obstacle_msg_pose.pose.position.y;
    //table_pose.position.z = Obstacle_msg_pose.pose.position.z;

    collision_object.primitives.push_back(primitive);
    collision_object.primitive_poses.push_back(table_pose);
    collision_object.operation = collision_object.ADD;

    std::vector<moveit_msgs::CollisionObject> collision_objects;
    collision_objects.push_back(collision_object);
    planning_scene_interface.applyCollisionObjects(collision_objects);
    ROS_INFO_NAMED("tutorial", "Add an object into the world");

    //ros::Duration(2.0).sleep(); 
#endif

#if 0
/* -------- Set the Object Collision -------- */
    moveit::planning_interface::PlanningSceneInterface planning_scene_interface_2;
    // Collision object
    moveit_msgs::CollisionObject collision_object_2;
    collision_object_2.header.frame_id = "base_footprint";
    collision_object_2.id = "table_2";

  /* All sahpes are defined to have their bounding boxes centered around 0,0,0 (base_footprint) */
    shape_msgs::SolidPrimitive primitive_2;
    primitive_2.type = primitive_2.BOX;
    primitive_2.dimensions.resize(3);
    primitive_2.dimensions[0] = 4;
    primitive_2.dimensions[1] = 0.1;
    primitive_2.dimensions[2] = 0.1;

    /* The X, Y, Z dimensions are the length of the corresponding sides of the Box */
    geometry_msgs::Pose table_pose_2;
    table_pose_2.orientation.w = 1;
    table_pose_2.position.x = 0;
    table_pose_2.position.y = 1.2;
    table_pose_2.position.z = 0.6;

    collision_object_2.primitives.push_back(primitive_2);
    collision_object_2.primitive_poses.push_back(table_pose_2);
    collision_object_2.operation = collision_object_2.ADD;

    std::vector<moveit_msgs::CollisionObject> collision_objects_2;
    collision_objects_2.push_back(collision_object_2);
    planning_scene_interface_2.applyCollisionObjects(collision_objects_2);
    ROS_INFO_NAMED("tutorial", "Add an object into the world");
#endif

#if 0
/* -------- Set the Object Collision -------- */
    moveit::planning_interface::PlanningSceneInterface planning_scene_interface_3;
    // Collision object
    moveit_msgs::CollisionObject collision_object_3;
    collision_object_3.header.frame_id = "base_footprint";
    collision_object_3.id = "table_3";

  /* All sahpes are defined to have their bounding boxes centered around 0,0,0 (base_footprint) */
    shape_msgs::SolidPrimitive primitive_3;
    primitive_3.type = primitive_2.BOX;
    primitive_3.dimensions.resize(3);
    primitive_3.dimensions[0] = 4;
    primitive_3.dimensions[1] = 0.1;
    primitive_3.dimensions[2] = 0.1;

    /* The X, Y, Z dimensions are the length of the corresponding sides of the Box */
    geometry_msgs::Pose table_pose_3;
    table_pose_3.orientation.w = 1;
    table_pose_3.position.x = 0;
    table_pose_3.position.y = -1.2;
    table_pose_3.position.z = 0.6;

    collision_object_3.primitives.push_back(primitive_3);
    collision_object_3.primitive_poses.push_back(table_pose_3);
    collision_object_3.operation = collision_object_3.ADD;

    std::vector<moveit_msgs::CollisionObject> collision_objects_3;
    collision_objects_3.push_back(collision_object_3);
    planning_scene_interface_2.applyCollisionObjects(collision_objects_3);
    ROS_INFO_NAMED("tutorial", "Add an object into the world");
#endif

  
  /* ------ Set the Maximum time to find the plane ------- */
  group_arm_torso.setPlanningTime(5.0);
  bool success = bool(group_arm_torso.plan(my_plan));
  if (!success)
  {
      throw std::runtime_error("No plan found");
  }
  ROS_INFO_STREAM("Plan found for Z Motion Adjusting in" << my_plan.planning_time_ << "seconds");

  /* --------- Execute the plan --------- */
  ros::Time strat = ros::Time::now();

  #if 1
  moveit::planning_interface::MoveItErrorCode e  = group_arm_torso.move(); 
  #else
  moveit::planning_interface::MoveItErrorCode e = group_arm_torso.asyncMove();
  #endif
  
  if(!bool(e))
  {
      throw std::runtime_error("Error execution plan");
  }
  else /* Motion Planning is completed */
  {
    
  }


}/* For Loop */

  //ROS_INFO_STREAM("\tZ Left E-E = " << group_arm_torso.getCurrentPose("arm_left_tool_link").pose.position.z);
  //ROS_INFO_STREAM("\tZ Right E-E = " << group_arm_torso.getCurrentPose("arm_right_tool_link").pose.position.z);
}


/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void  icr_Motionplanning_arms::Pose_X_Arm (int motion_type)
{
  
  moveit::planning_interface::MoveGroupInterface::Plan my_plan;
  moveit::planning_interface::MoveGroupInterface group_arm_torso(moveit_group);

  geometry_msgs::PoseStamped current_left_arm_pose;
  geometry_msgs::PoseStamped current_right_arm_pose;
  current_left_arm_pose   = group_arm_torso.getCurrentPose("arm_left_tool_link");
  current_right_arm_pose  = group_arm_torso.getCurrentPose("arm_right_tool_link");

  if ( motion_type == Motion1_OPEN_LOCK)
  {
    Left_Arm_pose.header.frame_id = "base_footprint";
    Left_Arm_pose.pose.position.x   = current_right_arm_pose.pose.position.x;
    Left_Arm_pose.pose.position.y   = current_right_arm_pose.pose.position.y;
    Left_Arm_pose.pose.position.z   = current_right_arm_pose.pose.position.z;
    Left_Arm_pose.pose.orientation = current_left_arm_pose.pose.orientation;
    group_arm_torso.setPoseTarget(Left_Arm_pose,"arm_left_tool_link") ;

    
    Right_Arm_pose.header.frame_id = "base_footprint";
    Right_Arm_pose.pose.position.x  = current_right_arm_pose.pose.position.x;
    Right_Arm_pose.pose.position.y  = current_right_arm_pose.pose.position.y;
    Right_Arm_pose.pose.position.z  = current_right_arm_pose.pose.position.z;
    Right_Arm_pose.pose.orientation = current_right_arm_pose.pose.orientation;
    group_arm_torso.setPoseTarget(Right_Arm_pose,"arm_right_tool_link");
  }
  else if(motion_type == Motion2_OPEN_LID)
  {
    Left_Arm_pose.header.frame_id = "base_footprint";
    Left_Arm_pose.pose.position.x   =  (Left_Side_Box.pose.position.x) - 0.15;
    Left_Arm_pose.pose.position.y   = current_left_arm_pose.pose.position.y;
    Left_Arm_pose.pose.position.z   = current_left_arm_pose.pose.position.z;
    Left_Arm_pose.pose.orientation  = current_left_arm_pose.pose.orientation;
    group_arm_torso.setPoseTarget(Left_Arm_pose,"arm_left_tool_link") ;

    
    Right_Arm_pose.header.frame_id = "base_footprint";
    Right_Arm_pose.pose.position.x  = (Right_Side_Box.pose.position.x) - 0.15;
    Right_Arm_pose.pose.position.y  = current_right_arm_pose.pose.position.y;
    Right_Arm_pose.pose.position.z  = current_right_arm_pose.pose.position.z;
    Right_Arm_pose.pose.orientation = current_right_arm_pose.pose.orientation;
    group_arm_torso.setPoseTarget(Right_Arm_pose,"arm_right_tool_link");
  }

  group_arm_torso.setPlannerId("SBLkConfigDefault");
  group_arm_torso.setStartStateToCurrentState();
  group_arm_torso.setMaxVelocityScalingFactor(1.0);
  group_arm_torso.setPoseReferenceFrame("base_footprint");

  //ROS_INFO("Round Value");
  //ROS_INFO_STREAM("\tRound Value = " << rond((float)Left_Side_Box.pose.position.x));

 
  /* ------ Set the Maximum time to find the plane ------- */
  group_arm_torso.setPlanningTime(5.0);
  
  bool success = bool(group_arm_torso.plan(my_plan));
  if (!success)
  {
      throw std::runtime_error("No plan found");
  }
  ROS_INFO_STREAM("Plan found for X adjusting in" << my_plan.planning_time_ << "seconds");

  /* --------- Execute the plan --------- */
  ros::Time strat = ros::Time::now();

  moveit::planning_interface::MoveItErrorCode e  = group_arm_torso.move();
  

  if(!bool(e))
  {
      throw std::runtime_error("Error execution plan");
  }
  else /* Motion Planning is completed */
  {
    
  }
  //ROS_INFO_STREAM("\tX Left E-E = " << group_arm_torso.getCurrentPose("arm_left_tool_link").pose.position.x);
  //ROS_INFO_STREAM("\tX Right E-E = " << group_arm_torso.getCurrentPose("arm_right_tool_link").pose.position.x);
}


/* ============================================================
* Fucntion Name: 
* Description:   
* Inputs:
* Outputs:
============================================================== */
void  icr_Motionplanning_arms::Pose_Y_Arm (int motion_type)
{

  moveit::planning_interface::MoveGroupInterface::Plan my_plan;
  moveit::planning_interface::MoveGroupInterface group_arm_torso(moveit_group);

  geometry_msgs::PoseStamped current_left_arm_pose;
  geometry_msgs::PoseStamped current_right_arm_pose;
  current_left_arm_pose  = group_arm_torso.getCurrentPose("arm_left_tool_link");
  current_right_arm_pose = group_arm_torso.getCurrentPose("arm_right_tool_link");

  if ( motion_type == Motion1_OPEN_LOCK)
  {
    Left_Arm_pose.header.frame_id   = "base_footprint";
    Left_Arm_pose.pose.position.x   = current_left_arm_pose.pose.position.x;
    Left_Arm_pose.pose.position.y   =  (Left_Side_Box.pose.position.y) + 0.1;
    Left_Arm_pose.pose.position.z   = current_left_arm_pose.pose.position.z;
    Left_Arm_pose.pose.orientation  = current_left_arm_pose.pose.orientation;
    group_arm_torso.setPoseTarget(Left_Arm_pose,"arm_left_tool_link");

    Right_Arm_pose.header.frame_id  = "base_footprint";
    Right_Arm_pose.pose.position.x  = current_right_arm_pose.pose.position.x;
    Right_Arm_pose.pose.position.y  = (Right_Side_Box.pose.position.y) - 0.1;
    Right_Arm_pose.pose.position.z  = current_right_arm_pose.pose.position.z;
    Right_Arm_pose.pose.orientation = current_right_arm_pose.pose.orientation;
    group_arm_torso.setPoseTarget(Right_Arm_pose,"arm_right_tool_link");
  }

  else if(motion_type == Motion2_OPEN_LID)
  {
    Left_Arm_pose.header.frame_id   = "base_footprint";
    Left_Arm_pose.pose.position.x   = current_left_arm_pose.pose.position.x;
    Left_Arm_pose.pose.position.y   =  (Left_Side_Box.pose.position.y) + 0.1;
    Left_Arm_pose.pose.position.z   = current_left_arm_pose.pose.position.z-0.05;
    Left_Arm_pose.pose.orientation  = current_left_arm_pose.pose.orientation;
    group_arm_torso.setPoseTarget(Left_Arm_pose,"arm_left_tool_link");

    Right_Arm_pose.header.frame_id  = "base_footprint";
    Right_Arm_pose.pose.position.x  = current_right_arm_pose.pose.position.x;
    Right_Arm_pose.pose.position.y  = (Right_Side_Box.pose.position.y) - 0.1;
    Right_Arm_pose.pose.position.z  = current_right_arm_pose.pose.position.z-0.05;
    Right_Arm_pose.pose.orientation = current_right_arm_pose.pose.orientation;
    group_arm_torso.setPoseTarget(Right_Arm_pose,"arm_right_tool_link");
  }
  

  group_arm_torso.setPlannerId("SBLkConfigDefault");
  group_arm_torso.setStartStateToCurrentState();
  group_arm_torso.setMaxVelocityScalingFactor(1.0);
  group_arm_torso.setPoseReferenceFrame("base_footprint");

  /* ------ Set the Maximum time to find the plane ------- */
  group_arm_torso.setPlanningTime(5.0);
  bool success = bool(group_arm_torso.plan(my_plan));
  if (!success)
  {
      throw std::runtime_error("No plan found");
  }
  ROS_INFO_STREAM("Plan found for Y adjusting in" << my_plan.planning_time_ << "seconds");

  /* --------- Execute the plan --------- */
  ros::Time strat = ros::Time::now();

  moveit::planning_interface::MoveItErrorCode e  = group_arm_torso.move();

  if(!bool(e))
  {
      throw std::runtime_error("Error execution plan");
  }
  else /* Motion Planning is completed */
  {
    
  }

  //ROS_INFO_STREAM("\tY Left E-E = " << group_arm_torso.getCurrentPose("arm_left_tool_link").pose.position.y);
  //ROS_INFO_STREAM("\tY Right E-E = " << group_arm_torso.getCurrentPose("arm_right_tool_link").pose.position.y);
}